package com.example.wastresstester

import android.app.ActivityManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : android.app.Activity() {
    private val bg = Color.rgb(8, 8, 8)
    private val panel = Color.rgb(22, 22, 22)
    private val red = Color.rgb(255, 59, 74)
    private val white = Color.rgb(240, 240, 240)
    private val muted = Color.rgb(160, 160, 160)
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)
    private var task: Future<*>? = null
    private lateinit var status: TextView
    private lateinit var memory: TextView
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshMemory()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(label("WA STRESS TESTER", 25, red, true))
        root.addView(label("ANDROID DEVICE DIAGNOSTICS", 11, muted, true).also {
            it.setPadding(0, dp(4), 0, dp(22))
        })

        val statusCard = card()
        status = label("STATUS  •  READY", 15, white, true)
        statusCard.addView(status)
        memory = label("RAM: reading…", 14, muted, false).also {
            it.setPadding(0, dp(12), 0, 0)
        }
        statusCard.addView(memory)
        root.addView(statusCard)

        root.addView(section("TEST MODULES"))
        root.addView(actionButton("START DEVICE LOAD TEST", red) { startLoadTest() })
        root.addView(actionButton("STOP TEST", Color.rgb(90, 90, 90)) { stopLoadTest() })
        root.addView(actionButton("REFRESH RAM MONITOR", panel) { refreshMemory() })
        root.addView(actionButton("LOCAL OTP FLOW DEMO", panel) { showOtpDemo() })
        root.addView(actionButton("CLEAR LOG", panel) {
            log.text = "No test events recorded."
        })

        root.addView(section("TEST LOG"))
        val logCard = card()
        log = label("No test events recorded.", 13, muted, false)
        logCard.addView(log)
        root.addView(logCard)

        root.addView(label(
            "This app tests its own process only. It does not control WhatsApp, read SMS, " +
                "intercept verification codes, or access another account.",
            11, muted, false
        ).also { it.setPadding(dp(2), dp(18), dp(2), 0) })
    }

    private fun startLoadTest() {
        if (!running.compareAndSet(false, true)) return
        status.text = "STATUS  •  RUNNING BOUNDED TEST"
        appendLog("Started 10-second CPU workload in this app.")
        task = executor.submit {
            val end = System.currentTimeMillis() + 10_000
            var value = 1L
            while (running.get() && System.currentTimeMillis() < end) {
                value = (value * 1664525L + 1013904223L) and 0x7fffffffL
            }
            handler.post {
                running.set(false)
                status.text = "STATUS  •  READY"
                appendLog("Workload finished. Check RAM monitor for current app memory.")
                refreshMemory()
            }
        }
    }

    private fun stopLoadTest() {
        running.set(false)
        task?.cancel(true)
        status.text = "STATUS  •  STOPPED"
        appendLog("Test stopped.")
    }

    private fun refreshMemory() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val totalMb = info.totalMem / (1024 * 1024)
        val availMb = info.availMem / (1024 * 1024)
        val runtime = Runtime.getRuntime()
        val usedAppMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        memory.text = "DEVICE RAM: ${totalMb - availMb} MB used / $totalMb MB total\n" +
            "APP HEAP: $usedAppMb MB used"
        appendLog("RAM monitor refreshed.")
    }

    private fun showOtpDemo() {
        val code = (100000..999999).random()
        appendLog("Local demo OTP generated: $code (not sent to WhatsApp or SMS).")
        status.text = "STATUS  •  LOCAL OTP DEMO"
    }

    private fun appendLog(message: String) {
        val old = log.text.toString()
        log.text = if (old == "No test events recorded.") message else "$message\n$old"
    }

    private fun section(text: String): TextView =
        label(text, 12, red, true).also { it.setPadding(dp(2), dp(22), 0, dp(10)) }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
    }.also { /* card container */ }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun actionButton(text: String, color: Int, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(white)
            setBackgroundColor(color)
            isAllCaps = false
            gravity = Gravity.CENTER
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)
            )
            p.topMargin = dp(8)
            layoutParams = p
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        stopLoadTest()
        executor.shutdownNow()
        super.onDestroy()
    }
}
